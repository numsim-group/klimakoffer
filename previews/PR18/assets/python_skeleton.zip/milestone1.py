import matplotlib.pyplot as plt
import numpy as np


def read_geography(filepath):
    pass


def robinson_projection(nlatitude, nlongitude):
    # Example data to demonstrate plotting against points that don't lie on a rectangular grid.
    x = np.array([[1.0, 2.0], [1.0, 1.8]])
    y = np.array([[1.0, 1.0], [2.0, 1.8]])

    return x, y


def plot_geo(geo_dat):
    # Example to demonstrate plotting against points that don't lie on a rectangular grid.
    x, y = robinson_projection(2, 2)

    # Start plotting.
    fig, ax = plt.subplots()

    data = np.array([[1.0, 2.0], [3.0, 4.0]])

    # Create contour plot of data against the coordinates in x and y.
    im = ax.contourf(x, y, data)
    ax.set_aspect("equal")

    # Colorbar with the same height as the plot. Code copied from
    # https://stackoverflow.com/a/18195921
    # create an axes on the right side of ax. The width of cax will be 5%
    # of ax and the padding between cax and ax will be fixed at 0.05 inch.
    from mpl_toolkits.axes_grid1 import make_axes_locatable
    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="5%", pad=0.05)
    cbar = plt.colorbar(im, cax=cax)

    # Adjust size of plot to viewport to prevent clipping of the legend.
    plt.tight_layout()
    plt.show()


# Run the code.
if __name__ == "__main__":
    plot_geo(None)
